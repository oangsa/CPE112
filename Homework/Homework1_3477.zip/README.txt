I don't clearly understand the assignment. So, I written both algorithm and the actual code inside the "arrayOperation.c" file. The algorithm located at the bottom of the file. Thank you.

BTW I'm not using any sort of the AI helping me. Please give me full score. Thank you so much :)))

